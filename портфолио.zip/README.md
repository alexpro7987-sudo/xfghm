# 📊 Sales Data Analyzer

## Описание
Веб-приложение для анализа и визуализации данных о продажах

## Технологии
- **Python 3.11**
- **Django 4.2**
- **PostgreSQL 15**
- **Bootstrap 5**
